# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for Halo — produces a single, portable Halo.exe.

Build:  pyinstaller Halo.spec --noconfirm
Output: dist/Halo.exe   (one file, no installation needed)

We bundle the Flask templates/ and static/ folders as data so the frozen
app can serve them via app.py's resource_path().
"""

block_cipher = None

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('templates', 'templates'),
        ('static', 'static'),
    ],
    hiddenimports=[
        'waitress',
        'jinja2',
        'flask',
        'requests',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # keep the binary small — these are not used by Halo
        'tkinter', 'numpy', 'PIL', 'cv2', 'matplotlib', 'pandas',
        'scipy', 'PyQt5', 'PySide2', 'test', 'unittest',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='Halo',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,               # compress if UPX is available (smaller exe)
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,           # keep a small console window (shows the URL / quit hint)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='docs/halo.ico',   # optional; build script creates a placeholder if missing
)
