#!/usr/bin/env bash
# ============================================================
#  Halo — portable binary builder (macOS / Linux)
#  Produces a single portable binary at  dist/Halo
# ============================================================
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo "   Halo  -  Building portable binary"
echo "============================================================"

if ! command -v python3 >/dev/null 2>&1; then
  echo "[ERROR] python3 not found. Install Python 3.9+ and retry."
  exit 1
fi

python3 -m venv .venv-build
# shellcheck disable=SC1091
source .venv-build/bin/activate

echo "Installing dependencies..."
python -m pip install --upgrade pip >/dev/null
pip install -r requirements.txt >/dev/null
pip install pyinstaller >/dev/null

echo "Building..."
pyinstaller Halo.spec --noconfirm --clean

if [ -f "dist/Halo" ]; then
  echo "============================================================"
  echo "   SUCCESS!  Portable binary -> dist/Halo"
  echo "============================================================"
else
  echo "[ERROR] Build did not produce dist/Halo. See messages above."
  exit 1
fi
