# 📦 Halo — Portable / No-Install Guide

Yes — Halo runs as a **portable, no-installation app**. Choose the option that
fits you. All three need **no admin rights** and can run **from a USB stick**.

---

## Option 1 — Single portable `Halo.exe`  🥇 (recommended)

One file. No Python needed on the target PC. Copy it anywhere and double-click.

### Build it once (on any Windows PC with Python 3.9+)
```
Double-click  build.bat
```
That script creates a clean environment, installs everything, and produces:
```
dist\Halo.exe        <-- your portable app (~12–18 MB)
```
Copy `dist\Halo.exe` to a USB stick, another PC, wherever. Double-click to run —
it opens your browser at `http://127.0.0.1:5000` automatically.

> Why must I build it? A Windows `.exe` can only be produced **on Windows**
> (PyInstaller is platform-native). The build is one double-click and ~2 minutes.

### Prefer the command line?
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt pyinstaller
pyinstaller Halo.spec --noconfirm --clean
```

---

## Option 2 — Portable folder + `Halo.bat`  🥈 (no build step)

If you'd rather not compile anything, ship the whole folder and let a tiny
first-run script set up a local environment **inside the folder** (nothing
touches the system, nothing needs admin).

```
Double-click  Halo.bat
```
First run creates a local `.venv\` beside the app and launches Halo; every run
after is instant. The folder stays fully self-contained and movable.

---

## Option 3 — Truly dependency-free with embeddable Python  🥉

For a folder that runs even on a PC with **no Python at all**:

1. Download **"Windows embeddable package (64-bit)"** from
   <https://www.python.org/downloads/windows/> and unzip it into `python\`
   inside the Halo folder.
2. Add `requests`, `flask`, `waitress` into that embeddable environment
   (via `get-pip.py`), or `pip download` the wheels on any PC and drop them in.
3. Launch with:
   ```bat
   python\python.exe app.py
   ```
Package the folder as a `.zip` — it now runs on any Windows machine, offline,
with zero installation. (Option 1's `.exe` does this more elegantly; use this
only if you specifically want an interpreter-based bundle.)

---

## 🍎 macOS / 🐧 Linux

The same `app.py` is cross-platform. Build a native binary with:
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt pyinstaller
pyinstaller Halo.spec --noconfirm --clean     # -> dist/Halo
```
(A macOS build must be made on macOS; a Linux build on Linux.)

---

## How to use the app (any option)

1. Turn on the camera; connect your laptop to its Wi-Fi
   **`YDXJ_xxxxxxx`** (password `1234567890`).
2. Launch Halo → your browser opens automatically.
3. Browse the gallery, tap the shutter to capture, or record video.
4. Close the console window to quit.

## Notes

- **SmartScreen**: the first time you run an unsigned `.exe`, Windows may warn
  “Windows protected your PC”. Click **More info → Run anyway**. (This is normal
  for any unsigned indie app; code-signing removes it but needs a paid cert.)
- **Antivirus**: PyInstaller one-file apps unpack to a temp dir at launch; some
  AVs flag this heuristically. The one-folder build (`--onedir`) avoids it — set
  `console=True` stays, just change the spec to `EXE(..., exclude_binaries=True)`
  + a `COLLECT()` if you want that variant. Ask me and I'll add it.
- **Port**: Halo auto-picks a free port (5000 → 5001 → 8000 …). Force one with
  `set HALO_PORT=5000` before launching.
