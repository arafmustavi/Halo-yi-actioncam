"""
Halo -- a minimalist gallery & capture app for the Xiaomi YI Action Camera.

Runs three ways from the SAME file:
  * python app.py                -> dev (Flask reloader off, opens browser)
  * packaged Halo.exe            -> PyInstaller one-file, fully portable
  * embeddable-python + Halo.bat -> zero-install portable folder

Portability notes:
  * resource_path() resolves bundled templates/static whether we're frozen
    (PyInstaller sets sys._MEIPASS) or running from source.
  * A production WSGI server (waitress) is used when available so there's no
    scary Flask "development server" banner in the packaged app.
  * A free port is auto-selected and the default browser is opened for you.
"""

import os
import re
import sys
import time
import socket
import threading
import webbrowser
from urllib.parse import unquote

import requests
from flask import Flask, Response, jsonify, render_template, request, abort

from yi_camera import YiCamera, YiCameraError


# ---------------------------------------------------------------------------
# Frozen-aware resource resolution (works in source, PyInstaller, embeddable)
# ---------------------------------------------------------------------------
def resource_path(rel):
    """Absolute path to a bundled resource, PyInstaller-safe."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


CAMERA_IP = os.environ.get("YI_IP", "192.168.42.1")

app = Flask(
    __name__,
    template_folder=resource_path("templates"),
    static_folder=resource_path("static"),
)

camera = YiCamera(ip=CAMERA_IP)
_state = {"recording": False, "rec_started": None}


def ensure_connected():
    if not camera.connected:
        camera.connect()


def api_error(exc, code=502):
    return jsonify({"ok": False, "error": str(exc)}), code


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", camera_ip=CAMERA_IP)


@app.route("/api/status")
def api_status():
    try:
        ensure_connected()
        bat = camera.battery()
        rec_secs = int(time.time() - _state["rec_started"]) if _state["rec_started"] else 0
        return jsonify({"ok": True, "connected": True,
                        "battery": bat, "recording": _state["recording"],
                        "rec_secs": rec_secs, "ip": CAMERA_IP})
    except YiCameraError as exc:
        return jsonify({"ok": False, "connected": False, "error": str(exc)})


@app.route("/api/capture", methods=["POST"])
def api_capture():
    try:
        ensure_connected()
        path = camera.take_photo()
        url = camera.http_url_for(path) if path else None
        return jsonify({"ok": True, "path": path, "url": url})
    except YiCameraError as exc:
        return api_error(exc)


@app.route("/api/record/start", methods=["POST"])
def api_record_start():
    try:
        ensure_connected()
        camera.start_recording()
        _state["recording"] = True
        _state["rec_started"] = time.time()
        return jsonify({"ok": True, "recording": True})
    except YiCameraError as exc:
        return api_error(exc)


@app.route("/api/record/stop", methods=["POST"])
def api_record_stop():
    try:
        ensure_connected()
        camera.stop_recording()
        _state["recording"] = False
        _state["rec_started"] = None
        return jsonify({"ok": True, "recording": False})
    except YiCameraError as exc:
        return api_error(exc)


# --- Gallery ---------------------------------------------------------------
MEDIA_RE = re.compile(r'\.(?:jpg|jpeg|mp4|mov)$', re.IGNORECASE)


def scrape_dir(url):
    files, dirs = [], []
    try:
        html = requests.get(url, timeout=6).text
    except requests.RequestException:
        return files, dirs
    for href in re.findall(r'href="([^"]+)"', html):
        if href in ("../", "./") or href.startswith("?"):
            continue
        full = url.rstrip("/") + "/" + href.lstrip("/")
        if href.endswith("/"):
            dirs.append(full)
        elif MEDIA_RE.search(href):
            files.append(full)
    return files, dirs


@app.route("/api/gallery")
def api_gallery():
    try:
        root = f"http://{CAMERA_IP}/DCIM/"
        all_files = []
        files, dirs = scrape_dir(root)
        all_files += files
        for d in dirs:
            f2, _ = scrape_dir(d)
            all_files += f2
        media = []
        for u in sorted(set(all_files), reverse=True):
            name = u.rsplit("/", 1)[-1]
            is_video = u.lower().endswith((".mp4", ".mov"))
            media.append({
                "url": u, "name": name,
                "type": "video" if is_video else "photo",
                "src": "/media?url=" + u,
            })
        return jsonify({"ok": True, "count": len(media), "media": media})
    except Exception as exc:  # noqa
        return jsonify({"ok": False, "error": str(exc)})


@app.route("/media")
def media_proxy():
    url = request.args.get("url", "")
    if not url.startswith(f"http://{CAMERA_IP}"):
        abort(400, "Only camera URLs are allowed.")
    headers = {}
    rng = request.headers.get("Range")
    if rng:
        headers["Range"] = rng
    try:
        r = requests.get(url, stream=True, timeout=20, headers=headers)
    except requests.RequestException as exc:
        return api_error(exc)
    resp = Response(r.iter_content(chunk_size=16384),
                    status=r.status_code,
                    content_type=r.headers.get("Content-Type", "application/octet-stream"))
    for h in ("Content-Length", "Content-Range", "Accept-Ranges"):
        if h in r.headers:
            resp.headers[h] = r.headers[h]
    return resp


@app.route("/api/download")
def api_download():
    url = request.args.get("url", "")
    if not url.startswith(f"http://{CAMERA_IP}"):
        abort(400, "Only camera URLs are allowed.")
    name = unquote(url.rsplit("/", 1)[-1])
    try:
        r = requests.get(url, stream=True, timeout=20)
        r.raise_for_status()
    except requests.RequestException as exc:
        return api_error(exc)
    return Response(r.iter_content(chunk_size=16384),
                    content_type=r.headers.get("Content-Type", "application/octet-stream"),
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------------------
# Launcher helpers (used only when run directly / as a packaged app)
# ---------------------------------------------------------------------------
def _find_free_port(preferred=5000):
    """Return the preferred port if free, else an OS-assigned free one."""
    for port in (preferred, 5001, 5050, 8000, 8080):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:  # nothing listening
                return port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _banner(url):
    line = "=" * 52
    print("\n" + line)
    print("   Halo  -  Camera Gallery")
    print(line)
    print(f"   Running at : {url}")
    print( "   Camera Wi-Fi: connect to  YDXJ_xxxxxxx  (pass 1234567890)")
    print( "   To quit    : close this window")
    print(line + "\n")


def main():
    port = _find_free_port(int(os.environ.get("HALO_PORT", "5000")))
    url = f"http://127.0.0.1:{port}"
    _banner(url)

    # open the browser shortly after the server starts
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    # Prefer a real production server so packaged app has no dev-server warning
    try:
        from waitress import serve
        serve(app, host="127.0.0.1", port=port, threads=8, _quiet=True)
    except Exception:
        app.run(host="127.0.0.1", port=port, threaded=True, debug=False,
                use_reloader=False)


if __name__ == "__main__":
    main()
