<p align="center">
  <img src="docs/halo_icon.png" width="120" alt="Halo icon">
</p>

<h1 align="center">Halo — Camera Gallery</h1>

<p align="center">
  <strong>A minimalist, Apple-inspired web app that turns an original Xiaomi YI Action Camera into a modern, browsable gallery — with capture and record — straight from your browser.</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.9%2B-3776AB?logo=python&logoColor=white">
  <img src="https://img.shields.io/badge/Flask-3.0-000000?logo=flask&logoColor=white">
  <img src="https://img.shields.io/badge/Frontend-Vanilla_JS-F7DF1E?logo=javascript&logoColor=black">
  <img src="https://img.shields.io/badge/Portable-EXE_ready-8A5BFF">
  <img src="https://img.shields.io/badge/License-MIT-green">
</p>

---

## 📖 Overview

The original Xiaomi YI Action Camera has **no screen** and its companion mobile app is **discontinued** — so once you have footage on the camera, there's no clean way to browse it from a laptop.

**Halo fixes that.** It speaks the camera's undocumented control protocol to trigger photo/video capture, reads media off the device over its built-in HTTP server, and presents everything in a polished, responsive gallery that feels like a first-party Apple app.

> 💡 Built on a **reverse-engineered TCP/JSON protocol** (port `7878`, token handshake). See [`docs`](docs) for screenshots.

---

## ✨ Features

| | Feature | Description |
|---|---|---|
| 🖼️ | **Unified gallery** | Every photo & video on the SD card in a responsive grid with smooth motion & lazy loading |
| 🎞️ | **Smart filters** | Segmented **All / Photos / Videos** control |
| 🔍 | **Immersive lightbox** | Full-screen viewer, blur backdrop, keyboard nav (`← →`, `Esc`), one-tap download |
| 📸 | **Remote capture** | Trigger a photo from the browser with a tactile shutter |
| ⏺️ | **Remote record** | Start/stop video with a live timer |
| 🔋 | **Live device status** | Connection indicator + battery, auto-polled |
| 📦 | **Portable / no-install** | Ship as a single **`Halo.exe`** — runs from a USB stick, no Python needed |

---

## 📦 Portable — No Installation Required

Halo ships as a **portable app**. Three ways, all **no-admin, USB-friendly**:

### 🥇 Single `Halo.exe` (recommended)
On any Windows PC with Python 3.9+:
```
Double-click  build.bat      ->  produces  dist\Halo.exe
```
Copy `dist\Halo.exe` anywhere and double-click — it opens your browser automatically. **No Python needed on the target machine.**

### 🥈 Portable folder (no build)
```
Double-click  Halo.bat       ->  sets up a local env in-folder & runs
```

### 🥉 Embeddable Python bundle
For PCs with no Python at all — see **[PORTABLE.md](PORTABLE.md)** for all options.

> A Windows `.exe` must be **built on Windows** (PyInstaller is platform-native).
> The provided `build.bat` makes this a single double-click (~2 min, one time).

---

## 🚀 Run from source (dev)

```bash
git clone https://github.com/arafmustavi/Halo.git
cd Halo
pip install -r requirements.txt

# Connect your laptop to the camera's Wi-Fi:
#   SSID: YDXJ_xxxxxxx   Password: 1234567890

python app.py            # -> opens http://127.0.0.1:5000
```

---

## 🏗️ Architecture

```
┌──────────────┐        HTTP/JSON        ┌─────────────────────┐
│   Browser    │  ◄──────────────────►   │   Flask backend     │
│  (Halo UI)   │      /api/* routes      │      (app.py)       │
└──────────────┘                         └──────────┬──────────┘
                          ┌─────────────────────────┼─────────────────────────┐
                   TCP :7878 JSON              HTTP :80 files            proxy /media
                   token handshake             /DCIM/ listing            (range support)
                          ▼                          ▼                         ▼
                 ┌───────────────────────────────────────────────────────────────┐
                 │           Xiaomi YI Action Camera  (YDXJ_v25L)                 │
                 └───────────────────────────────────────────────────────────────┘
```

- **`yi_camera.py`** — reusable client for the camera's TCP/JSON protocol (token handshake, streaming JSON parser, typed commands).
- **`app.py`** — Flask REST API + media proxy with HTTP `Range` support (so video scrubbing works). Frozen-aware for `.exe` packaging; auto-opens the browser; production `waitress` server.
- **`static/` + `templates/`** — dependency-free frontend (vanilla JS + hand-built CSS design system). No build step.

---

## 🧠 Engineering Story

A case study in **debugging the unknown and pragmatic decision-making**: I reverse-engineered the control protocol, targeted live video for on-device object detection, then isolated a **`461 Unsupported Transport`** RTSP failure to a **defect in this firmware's streaming stack** (verified across UDP/TCP, OpenCV, FFmpeg, and VLC). Rather than chase an unfixable stream, I **pivoted the product** to what the hardware does flawlessly — gallery, capture, record — and invested in exceptional UX. Halo is the result.

---

## 📂 Project Structure

```
halo/
├── app.py              # Flask backend (frozen-aware) + media proxy
├── yi_camera.py        # Camera protocol client (TCP :7878)
├── Halo.spec           # PyInstaller build recipe (-> portable Halo.exe)
├── build.bat / build.sh# One-click builders (Windows / *nix)
├── Halo.bat            # No-build portable launcher (Windows)
├── PORTABLE.md         # Full portable/no-install guide
├── templates/index.html
├── static/{style.css, app.js}
├── docs/               # icon, screenshots
├── requirements.txt
└── README.md
```

---

## 🛠️ Tech Stack

**Backend:** Python · Flask · waitress · raw TCP sockets · custom JSON protocol
**Frontend:** Vanilla JavaScript (zero deps) · hand-crafted CSS design system
**Packaging:** PyInstaller (single-file, portable)

---

## 📄 License

MIT — see [`LICENSE`](LICENSE).
