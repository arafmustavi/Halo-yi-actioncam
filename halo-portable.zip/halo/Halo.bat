@echo off
REM ============================================================
REM  Halo — portable launcher (no build, no install)
REM  Use this if you DON'T want to compile an .exe.
REM  Requires Python 3.9+ on PATH. First run sets up a local
REM  virtual environment inside this folder, then launches Halo.
REM ============================================================
setlocal
title Halo
cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python 3.9+ not found on PATH. Install from https://python.org
    pause
    exit /b 1
)

if not exist ".venv\Scripts\activate.bat" (
    echo First run: setting up a local environment ^(one time^)...
    python -m venv .venv
    call ".venv\Scripts\activate.bat"
    python -m pip install --upgrade pip >nul
    pip install -r requirements.txt >nul
) else (
    call ".venv\Scripts\activate.bat"
)

python app.py
