@echo off
REM ============================================================
REM  Halo — one-click portable EXE builder (Windows)
REM  Double-click this file. It will:
REM    1. create a clean virtual environment
REM    2. install Halo's dependencies + PyInstaller
REM    3. build a single, portable  dist\Halo.exe
REM  No prior setup needed except Python 3.9+ on your PATH.
REM ============================================================
setlocal enabledelayedexpansion
title Halo - Portable EXE Builder
cd /d "%~dp0"

echo.
echo ============================================================
echo    Halo  -  Building portable Halo.exe
echo ============================================================
echo.

REM --- 1. Check Python ---------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on your PATH.
    echo         Install Python 3.9+ from https://python.org
    echo         and tick "Add Python to PATH" during setup.
    echo.
    pause
    exit /b 1
)
for /f "delims=" %%v in ('python --version') do echo Using %%v

REM --- 2. Virtual environment --------------------------------
if not exist ".venv-build" (
    echo Creating build virtual environment...
    python -m venv .venv-build
)
call ".venv-build\Scripts\activate.bat"

REM --- 3. Dependencies ---------------------------------------
echo Installing dependencies (this runs once)...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt >nul
pip install pyinstaller >nul

REM --- 4. Build ----------------------------------------------
echo.
echo Building the executable... (first build takes ~1-2 minutes)
echo.
pyinstaller Halo.spec --noconfirm --clean

REM --- 5. Result ---------------------------------------------
echo.
if exist "dist\Halo.exe" (
    echo ============================================================
    echo    SUCCESS!  Your portable app is ready:
    echo        dist\Halo.exe
    echo    Copy it anywhere ^(even a USB stick^) and double-click.
    echo ============================================================
) else (
    echo [ERROR] Build did not produce dist\Halo.exe. See messages above.
)
echo.
pause
